const { ObjectID } = require('mongodb');

const tools = {
  capitalize: val => val.charAt(0).toUpperCase() + val.slice(1),
  domainRegExp: /^(?!:\/\/)([a-zA-Z0-9-_]+\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11}?$/i,
  emailRegExp: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  ethAdressRegExp: /^0x[a-fA-F0-9]{40}$/,
  escapedString: str => str.replace(/[$[+*|()^?.\\/]/g, '\\$&'),
  getMongoID: id => {
    if (id instanceof ObjectID) {
      return id;
    }

    try {
      const needId = new ObjectID(id);
      return needId;
    } catch (error) {
      throw new Error('Incorrect id');
    }
  },
  has: Object.prototype.hasOwnProperty,
  isArray: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Array]',
  isObject: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Object]',
  isString: maybyObj => Object.prototype.toString.call(maybyObj) === '[object String]',
  isNumber: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Number]',
  isRegExp: maybyObj => Object.prototype.toString.call(maybyObj) === '[object RegExp]',
  isFunction: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Function]',
  isUndefined: maybyObj => typeof maybyObj === 'undefined',
  isError: maybyObj => maybyObj instanceof Error,
  passwordRegExp: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/,
  urlRegExp: /^(https?:\/\/)?(?:[^@/\n]+@)?(?:www\.)?([^:/\n]+)((?::\d+)?)/iy
};

module.exports = tools;