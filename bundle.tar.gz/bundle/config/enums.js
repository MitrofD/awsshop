Enums = {
  TMP_PREFIX: 'tmp_',
  SESS_USER_ID: 'id',
  SESS_USER_IS_ADMIN: 'isAdmin',
  SESS_USER_EMAIL: 'email'
};