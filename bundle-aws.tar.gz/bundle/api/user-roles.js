const tools = require('./tools');

const ROLE = {
  ADMIN: 'ADMIN',
  USER: 'USER'
};

const userRoles = {
  TYPE: ROLE,

  exists: role => tools.has.call(ROLE, role),

  check(role) {
    if (!this.exists(role)) {
      throw new Error(`Role "${role}" not exists`);
    }
  }
};

module.exports = userRoles;