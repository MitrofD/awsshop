const { ObjectID } = require('mongodb');

const tools = {
  anyAsObj: data => typeof data === 'object' && data !== null ? data : {},
  anyAsStr: data => typeof data === 'string' && data !== null ? data : '',
  capitalize: val => val.charAt(0).toUpperCase() + val.slice(1),
  dateFromData: mbDate => {
    if (mbDate instanceof Date) {
      return mbDate;
    }

    const intVal = parseInt(mbDate);
    const date = new Date(intVal);
    const dateTime = date.getTime();

    if (Number.isNaN(dateTime)) {
      return null;
    }

    return date;
  },

  domainRegExp: /^(?!:\/\/)([a-zA-Z0-9-_]+\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11}?$/i,
  emailRegExp: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  USDPMWalletRegExp: /^U\d{8}$/,
  escapedString: str => str.replace(/[$[+*|()^?.\\/]/g, '\\$&'),
  getMongoID: id => {
    if (id instanceof ObjectID) {
      return id;
    }

    try {
      const needId = new ObjectID(id);
      return needId;
    } catch (error) {
      throw new Error('Incorrect id');
    }
  },
  has: Object.prototype.hasOwnProperty,
  isArray: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Array]',
  isObject: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Object]',
  isString: maybyObj => Object.prototype.toString.call(maybyObj) === '[object String]',
  isNumber: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Number]',
  isRegExp: maybyObj => Object.prototype.toString.call(maybyObj) === '[object RegExp]',
  isFunction: maybyObj => Object.prototype.toString.call(maybyObj) === '[object Function]',
  isUndefined: maybyObj => typeof maybyObj === 'undefined',
  isError: maybyObj => maybyObj instanceof Error,
  passwordRegExp: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/,
  urlRegExp: /^(https?:\/\/)?(?:[^@/\n]+@)?(?:www\.)?([^:/\n]+)((?::\d+)?)/iy
};

module.exports = tools;