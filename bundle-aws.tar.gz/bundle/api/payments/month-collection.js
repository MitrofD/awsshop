
/*
const collection = MongoStore.collection('month-payments');

[
  'createdAt',
  'monthYear',
  'userId',
].forEach((key) => {
  collection.createIndex({
    [key]: 1,
  });
});

module.exports = collection;
*/