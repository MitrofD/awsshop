
/*
const collection = MongoStore.collection('payments');

[
  'createdAt',
  'userId',
].forEach((key) => {
  collection.createIndex({
    [key]: 1,
  });
});

module.exports = collection;
*/