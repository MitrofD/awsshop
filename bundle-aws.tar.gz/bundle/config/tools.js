const tools = require('../api/tools');

Tools = tools;

Tools.dateAsUTCString = (date, separator = ' ') => {
  const month = date.getUTCMonth() + 1;
  const dateStr = date.getUTCFullYear() + '-' + ('0' + month).slice(-2) + '-' + ('0' + date.getUTCDate()).slice(-2);
  const timeStr = ('0' + date.getUTCHours()).slice(-2) + ':' + ('0' + date.getUTCMinutes()).slice(-2) + ':' + ('0' + date.getUTCSeconds()).slice(-2);
  return dateStr + separator + timeStr;
};

Tools.sendEmailError = new Error('Sending email error');

Tools.genUnknownError = action => new Error(`Unknown error [${action}]`);

// eslint-disable-next-line no-console
Tools.emptyRejectExeption = isDevMode ? error => console.log(error.message) : () => {};

Tools.startOfMonthDate = () => {
  const now = new Date();
  now.setDate(1);
  now.setHours(0, 0, 0);

  return now;
};

Tools.okObj = {
  ok: true
};